<?php
include 'db_connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nic      = $_POST['nic'];
    $campaign = $_POST['campaign_id'];
    $amount   = $_POST['amount'];

    $sql = "INSERT INTO donations (nic_number, campaign_id, amount) 
            VALUES ('$nic', '$campaign', '$amount')";

    if ($conn->query($sql) === TRUE) {
        echo "Donation recorded successfully!";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
</head>
<body>
    <form method="POST" action="donation_form.php">
  <input type="text" name="nic" placeholder="Donor NIC Number" required><br>
  <input type="number" name="campaign_id" placeholder="Campaign ID" required><br>
  <input type="number" step="0.01" name="amount" placeholder="Donation Amount" required><br>
  <button type="submit">Donate</button>
</form>

</body>
</html>