<?php
include 'db_connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name  = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $nic   = $_POST['nic'];

    $sql = "INSERT INTO donors (name, email, phone, nic_number) 
            VALUES ('$name', '$email', '$phone', '$nic')";

    if ($conn->query($sql) === TRUE) {
        echo "New donor registered successfully!";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
</head>
<body>
    <form method="POST" action="donor_register.php">
  <input type="text" name="name" placeholder="Full Name" required><br>
  <input type="email" name="email" placeholder="Email" required><br>
  <input type="text" name="phone" placeholder="Phone"><br>
  <input type="text" name="nic" placeholder="NIC Number" required><br>
  <button type="submit">Register Donor</button>
</form>

</body>
</html>