<?php
include 'db_connection.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Donation Management System</title>
    <link rel="stylesheet" href="style.css">
    <style>
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f9fafc;
            color: #333;
        }

        header {
            background: #ffffff;
            box-shadow: 0px 3px 6px rgba(0,0,0,0.05);
            padding: 1em 3em;
            position: sticky;
            top: 0;
            z-index: 100;
        }

        nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        nav h1 {
            font-size: 1.8rem;
            font-weight: 800;
            color: #007bff;
            letter-spacing: 1px;
        }

        nav ul {
            display: flex;
            gap: 1.5em;
            list-style: none;
        }

        nav a {
            text-decoration: none;
            color: #333;
            font-weight: 600;
            transition: 0.3s;
        }

        nav a:hover {
            color: #007bff;
        }

        .donate-btn {
            background: #28a745;
            color: #fff !important;
            padding: 8px 18px;
            border-radius: 25px;
            transition: 0.3s;
        }

        .donate-btn:hover {
            background: #218838;
            text-decoration: none;
        }

       
        .hero {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 3em;
            padding: 3em 5%;
            background: linear-gradient(to right, #eef6ff, #ffffff);
        }

        .hero img {
            width: 400px;
            border-radius: 15px;
            box-shadow: 0px 5px 15px rgba(0,0,0,0.1);
        }

        .hero-text {
            max-width: 600px;
            text-align: left;
        }

        .hero-text h2 {
            font-size: 2.2rem;
            color: #222;
            margin-bottom: 1em;
        }

        .hero-text p {
            font-size: 1.1rem;
            line-height: 1.7;
            margin-bottom: 1.5em;
            color: #555;
        }

        .hero-text .cta-btn {
            background: #007bff;
            color: #fff;
            padding: 12px 25px;
            border-radius: 30px;
            text-decoration: none;
            font-weight: bold;
            transition: 0.3s;
        }

        .hero-text .cta-btn:hover {
            background: #0056b3;
        }

       
        .quote-box {
            margin: 3em auto;
            padding: 2em;
            width: 80%;
            background: #007bff;
            color: #fff;
            text-align: center;
            border-radius: 15px;
            font-size: 1.3rem;
            font-style: italic;
            font-weight: 500;
            box-shadow: 0px 5px 15px rgba(0,0,0,0.1);
        }

        .quote-box span {
            display: block;
            margin-top: 1em;
            font-size: 1rem;
            font-style: normal;
            font-weight: bold;
        }

        
        .grid-container {
            margin: 3em auto;
            width: 85%;
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 1.5em;
        }

        .grid-container img {
            width: 100%;
            border-radius: 12px;
            object-fit: cover;
            box-shadow: 0px 5px 12px rgba(0,0,0,0.1);
            transition: transform 0.3s, box-shadow 0.3s;
        }

        .grid-container img:hover {
            transform: scale(1.05);
            box-shadow: 0px 8px 18px rgba(0,0,0,0.15);
        }

        footer {
            text-align: center;
            padding: 1.5em;
            background: #f1f1f1;
            color: #555;
            margin-top: 3em;
            font-size: 0.9rem;
        }

        footer a {
            color: #007bff;
            text-decoration: none;
            margin: 0 8px;
        }

        footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>


<header>
    <nav>
        <h1>Donation Management</h1>
        <ul>
            <li><a href="donor_register.php">Register Donor</a></li>
            <li><a href="donation_form.php">Make a Donation</a></li>
            <li><a href="campaign_add.php">Add Campaign</a></li>
            <li><a href="about.php">About</a></li>
            <li><a href="contact.php">Contact</a></li>
            <li><a href="donation_form.php" class="donate-btn">Donate</a></li>
        </ul>
    </nav>
</header>


<section class="hero">
    <img src="image/donation.jpg" alt="Donation Image">
    <div class="hero-text">
        <h2>Make a Difference Today</h2>
        <p>
            Your help can break the cycle of poverty by empowering the world's most 
            disadvantaged people to overcome the challenges they face. Your gift 
            provides healthcare, education, and disaster relief, ensuring that 
            vulnerable communities can build sustainable futures.
        </p>
        <a href="donation_form.php" class="cta-btn">Start Donating</a>
    </div>
</section>

<div class="quote-box">
    “Do your little bit of good where you are; it's those little bits of good put together that overwhelm the world.”
    <span>– Archbishop Desmond Tutu</span>
</div>


<section id="give-your-hand">
    <div class="grid-container">
        <img src="image/img-1.jpg" alt="Help Image 1">
        <img src="image/img-2.jpg" alt="Help Image 2">
        <img src="image/img-3.jpg" alt="Help Image 3">
        <img src="image/img-4.jpg" alt="Help Image 4">
    </div>
</section>


<footer>
    <p>© <?php echo date("Y"); ?> Donation Management System. All rights reserved.</p>
    <p>
        <a href="about.php">About</a> | 
        <a href="contact.php">Contact</a>
    </p>
</footer>

</body>
</html>
