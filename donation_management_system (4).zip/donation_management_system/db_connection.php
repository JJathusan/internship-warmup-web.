<?php
$servername = "localhost";   // Database host
$username   = "root";        // DB username
$password   = "";            // DB password
$dbname     = "donation_db"; // Your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
