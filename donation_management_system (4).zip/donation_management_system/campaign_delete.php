<?php
session_start();
include 'db_connection.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit();
}

if (!isset($_GET['id'])) {
    die("Invalid request.");
}

$campaign_id = intval($_GET['id']);

$sql = "DELETE FROM campaigns WHERE campaign_id = $campaign_id";

if ($conn->query($sql) === TRUE) {
    header("Location: index.php?message=Campaign deleted successfully");
    exit();
} else {
    echo "Error deleting campaign: " . $conn->error;
}
?>
