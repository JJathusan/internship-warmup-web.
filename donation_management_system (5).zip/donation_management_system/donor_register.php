<?php
include 'db_connection.php';

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name  = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $nic   = $_POST['nic'];

    $sql = "INSERT INTO donors (name, email, phone, nic_number) 
            VALUES ('$name', '$email', '$phone', '$nic')";

    if ($conn->query($sql) === TRUE) {
        $message = '<div class="alert alert-success text-center">🎉 Donor registered successfully!</div>';
    } else {
        $message = '<div class="alert alert-danger text-center">❌ Error: ' . $conn->error . '</div>';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Register Donor</title>
  <!-- ✅ Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<!-- ✅ Navbar -->
<nav class="navbar navbar-expand-lg bg-white shadow-sm sticky-top">
  <div class="container">
    <a class="navbar-brand fw-bold text-primary" href="index.php">Donation Management</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
        <li class="nav-item"><a class="nav-link active fw-bold" href="donor_register.php">Register</a></li>
        <li class="nav-item"><a class="nav-link" href="donation_form.php">Donate</a></li>
      </ul>
    </div>
  </div>
</nav>

<!-- ✅ Donor Registration Form -->
<div class="container py-5">
  <div class="row justify-content-center">
    <div class="col-md-6">

      <div class="card shadow-lg border-0 rounded-4">
        <div class="card-body p-4">
          <h3 class="text-center text-primary mb-4">📝 Register as a Donor</h3>

          <!-- Success/Error Message -->
          <?php if (!empty($message)) echo $message; ?>

          <form method="POST" action="donor_register.php">
            <div class="mb-3">
              <label for="name" class="form-label">Full Name</label>
              <input type="text" class="form-control" id="name" name="name" placeholder="Enter your full name" required>
            </div>

            <div class="mb-3">
              <label for="email" class="form-label">Email Address</label>
              <input type="email" class="form-control" id="email" name="email" placeholder="Enter email" required>
            </div>

            <div class="mb-3">
              <label for="phone" class="form-label">Phone Number</label>
              <input type="text" class="form-control" id="phone" name="phone" placeholder="Enter phone number">
            </div>

            <div class="mb-3">
              <label for="nic" class="form-label">NIC Number</label>
              <input type="text" class="form-control" id="nic" name="nic" placeholder="Enter NIC number" required>
            </div>

            <div class="d-grid">
              <button type="submit" class="btn btn-success btn-lg rounded-pill">Register Now</button>
            </div>
          </form>
        </div>
      </div>

    </div>
  </div>
</div>

<!-- ✅ Footer -->
<footer class="bg-white text-center py-3 border-top mt-5">
  <p class="mb-0">© <?php echo date("Y"); ?> Donation Management System. All rights reserved.</p>
</footer>

<!-- ✅ Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
