<?php
session_start();
include 'db_connection.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Donation Management System</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">

    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f9fafc; color: #333; }
        header { background: #ffffff; box-shadow: 0px 3px 6px rgba(0,0,0,0.05); padding: 1em 3em; position: sticky; top: 0; z-index: 100; }
        nav { display: flex; justify-content: space-between; align-items: center; }
        nav h1 { font-size: 1.8rem; font-weight: 800; color: #007bff; letter-spacing: 1px; }
        nav ul { display: flex; gap: 1.5em; list-style: none; }
        nav a { text-decoration: none; color: #333; font-weight: 600; transition: 0.3s; }
        nav a:hover { color: #007bff; }
        .donate-btn { background: #28a745; color: #fff !important; padding: 8px 18px; border-radius: 25px; transition: 0.3s; }
        .donate-btn:hover { background: #218838; text-decoration: none; }

        .hero { display: flex; justify-content: center; align-items: center; gap: 3em; padding: 3em 5%; background: linear-gradient(to right, #eef6ff, #ffffff); flex-wrap: wrap; }
        .hero img { width: 400px; border-radius: 15px; box-shadow: 0px 5px 15px rgba(0,0,0,0.1); }
        .hero-text { max-width: 600px; text-align: left; }
        .hero-text h2 { font-size: 2.2rem; color: #222; margin-bottom: 1em; }
        .hero-text p { font-size: 1.1rem; line-height: 1.7; margin-bottom: 1.5em; color: #555; }
        .hero-text .cta-btn { background: #007bff; color: #fff; padding: 12px 25px; border-radius: 30px; text-decoration: none; font-weight: bold; transition: 0.3s; }
        .hero-text .cta-btn:hover { background: #0056b3; }

        .quote-box { margin: 2em auto 1em auto; padding: 2em; width: 80%; background: #007bff; color: #fff; text-align: center; border-radius: 15px; font-size: 1.3rem; font-style: italic; font-weight: 500; box-shadow: 0px 5px 15px rgba(0,0,0,0.1); }
        .quote-box span { display: block; margin-top: 1em; font-size: 1rem; font-style: normal; font-weight: bold; }

        .grid-container { margin: 1.5em auto 0 auto; width: 85%; display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 1.5em; }
        .grid-container img { width: 100%; border-radius: 12px; object-fit: cover; box-shadow: 0px 5px 12px rgba(0,0,0,0.1); transition: transform 0.3s, box-shadow 0.3s; }
        .grid-container img:hover { transform: scale(1.05); box-shadow: 0px 8px 18px rgba(0,0,0,0.15); }

        /* About */
        .about { padding: 2.5em 1.5em; background: #fff; width: 85%; margin: 1em auto 0 auto; border-radius: 12px; box-shadow: 0px 4px 12px rgba(0,0,0,0.05); text-align: center; }
        .about h2 { color: #007bff; margin-bottom: 1em; font-size: 2rem; }
        .about p { color: #555; line-height: 1.8; max-width: 900px; margin: auto; }
        .about .cta-btn { margin-top: 1.5em; display: inline-block; }

        /* Campaign */
        .campaigns { width: 90%; margin: 2em auto; text-align: center; }
        .campaigns h2 { margin-bottom: 1em; color: #222; font-size: 2rem; }
        .campaign-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 1.5em; }
        .campaign-card { 
            background: #fff; 
            border-top: 4px solid #007bff; 
            border-radius: 12px; 
            box-shadow: 0px 4px 12px rgba(0,0,0,0.1); 
            padding: 1.2em; 
            text-align: left; 
            transition: transform 0.3s ease; 
        }
        .campaign-card:hover { transform: translateY(-5px); }
        .campaign-card h3 { color: #007bff; margin-bottom: 0.6em; font-size: 1.3rem; }
        .campaign-card p { color: #444; margin-bottom: 0.5em; }
        .campaign-card a { background: #28a745; color: #fff; padding: 8px 16px; border-radius: 20px; text-decoration: none; font-weight: 600; }
        .campaign-card a:hover { background: #218838; }

        footer { text-align: center; padding: 1.5em; background: #f1f1f1; color: #555; margin-top: 2em; font-size: 0.9rem; }
        footer a { color: #007bff; text-decoration: none; margin: 0 8px; }
        footer a:hover { text-decoration: underline; }
    </style>
</head>
<body>

<header>
    <nav>
        <h1>Donation Management</h1>
        <ul class="nav-links">
            <li><a href="donor_register.php">Register Donor</a></li>
            <li><a href="#about">About</a></li>
            <li><a href="contact.php">Contact</a></li>
            <?php if(isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
                <li><a href="campaign_add.php">Add Campaign</a></li>
                <li><a href="logout.php" class="logout-link"><i class="bi bi-box-arrow-right"></i></a></li>
            <?php else: ?>
                <li><a href="login.php" class="login-icon"><i class="bi bi-person-circle"></i></a></li>
            <?php endif; ?>
        </ul>
    </nav>
</header>

<section class="hero">
    <img src="image/donation.jpg" alt="Donation Image">
    <div class="hero-text">
        <h2>Make a Difference Today</h2>
        <p>
            Your help can break the cycle of poverty by empowering the world's most 
            disadvantaged people to overcome the challenges they face. Your gift 
            provides healthcare, education, and disaster relief, ensuring that 
            vulnerable communities can build sustainable futures.
        </p>
        <a href="donation_form.php" class="cta-btn">Start Donating</a>
    </div>
</section>

<div class="quote-box">
    “Do your little bit of good where you are; it's those little bits of good put together that overwhelm the world.”
    <span>– Archbishop Desmond Tutu</span>
</div>

<section id="give-your-hand">
    <div class="grid-container">
        <img src="image/img-1.jpg" alt="Help Image 1">
        <img src="image/img-2.jpg" alt="Help Image 2">
        <img src="image/img-3.jpg" alt="Help Image 3">
        <img src="image/img-4.jpg" alt="Help Image 4">
    </div>
</section>

<!-- About -->
<section class="about" id="about">
    <h2>About Us</h2>
    <p>
        The <strong>Donation Management System</strong> is designed to connect 
        generous donors with underprivileged communities, ensuring that every 
        contribution makes a real difference.
        Every donation helps provide <strong>education, healthcare, food, 
        and relief</strong> to those who need it most. Together, we aim to 
        create a brighter future for vulnerable families worldwide.
    </p>
    <a href="donation_form.php" class="cta-btn">Start Donating Today</a>
</section>

<!-- Campaign -->
<section class="campaigns">
    <h2>Active Campaigns</h2>
    <div class="campaign-grid">
        <?php
        $result = $conn->query("SELECT * FROM campaigns ORDER BY campaign_id DESC LIMIT 4");

        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<div class='campaign-card'>
                        <h3>" . htmlspecialchars($row['title']) . "</h3>
                        <p>" . htmlspecialchars($row['description']) . "</p>
                        <p><strong>Start:</strong> " . htmlspecialchars($row['start_date']) . "</p>
                        <p><strong>End:</strong> " . htmlspecialchars($row['end_date']) . "</p>
                        <a href='donation_form.php?campaign_id=" . $row['campaign_id'] . "'>Donate Now</a>";

                // Show Edit & Delete only if admin is logged in
                if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') {
                    echo " 
                        <a href='campaign_edit.php?id=" . $row['campaign_id'] . "' 
                           style='background:#ffc107; color:#000; padding:6px 12px; 
                                  border-radius:6px; text-decoration:none; margin-left:10px;'>
                           Edit
                        </a>
                        <a href='campaign_delete.php?id=" . $row['campaign_id'] . "' 
                           onclick=\"return confirm('Are you sure you want to delete this campaign?')\"
                           style='background:#dc3545; color:#fff; padding:6px 12px; 
                                  border-radius:6px; text-decoration:none; margin-left:10px;'>
                           Delete
                        </a>";
                }

                echo "</div>";
            }
        } else {
            echo "<p style='text-align:center; color:#666;'>No active campaigns right now.</p>";
        }
        ?>
    </div>
</section>


<footer>
    <p>© <?php echo date("Y"); ?> Donation Management System. All rights reserved.</p>
    <p>
        <a href="#about">About</a> | 
        <a href="contact.php">Contact</a>
    </p>
</footer>

</body>
</html>
