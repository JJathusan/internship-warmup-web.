<?php
session_start();
include 'db_connection.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit();
}

if (!isset($_GET['id'])) {
    die("Invalid request.");
}

$campaign_id = intval($_GET['id']);


$sql = "SELECT * FROM campaigns WHERE campaign_id = $campaign_id";
$result = $conn->query($sql);

if (!$result || $result->num_rows == 0) {
    die("Campaign not found.");
}

$campaign = $result->fetch_assoc();


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $conn->real_escape_string($_POST['title']);
    $description = $conn->real_escape_string($_POST['description']);
    $start_date = $conn->real_escape_string($_POST['start_date']);
    $end_date = $conn->real_escape_string($_POST['end_date']);

    $update_sql = "UPDATE campaigns 
                   SET title='$title', description='$description', 
                       start_date='$start_date', end_date='$end_date' 
                   WHERE campaign_id=$campaign_id";

    if ($conn->query($update_sql) === TRUE) {
        header("Location: index.php?message=Campaign updated successfully");
        exit();
    } else {
        echo "Error updating campaign: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Campaign</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h2 style="text-align:center; margin:20px;">Edit Campaign</h2>
    <form method="POST" style="max-width:600px; margin:auto; background:#fff; padding:20px; border-radius:10px; box-shadow:0px 4px 12px rgba(0,0,0,0.1);">
        <label>Campaign Title:</label>
        <input type="text" name="title" value="<?php echo htmlspecialchars($campaign['title']); ?>" required style="width:100%; padding:8px; margin-bottom:10px;">

        <label>Description:</label>
        <textarea name="description" rows="5" required style="width:100%; padding:8px; margin-bottom:10px;"><?php echo htmlspecialchars($campaign['description']); ?></textarea>

        <label>Start Date:</label>
        <input type="date" name="start_date" value="<?php echo htmlspecialchars($campaign['start_date']); ?>" required style="width:100%; padding:8px; margin-bottom:10px;">

        <label>End Date:</label>
        <input type="date" name="end_date" value="<?php echo htmlspecialchars($campaign['end_date']); ?>" required style="width:100%; padding:8px; margin-bottom:10px;">

        <button type="submit" style="padding:10px 20px; background:#007bff; color:white; border:none; border-radius:6px; cursor:pointer;">Update Campaign</button>
    </form>
</body>
</html>
