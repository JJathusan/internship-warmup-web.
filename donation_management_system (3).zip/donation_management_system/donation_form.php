<?php
include 'db_connection.php';

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nic      = $_POST['nic'];
    $campaign = $_POST['campaign_id'];
    $amount   = $_POST['amount'];

    $sql = "INSERT INTO donations (nic_number, campaign_id, amount) 
            VALUES ('$nic', '$campaign', '$amount')";

    if ($conn->query($sql) === TRUE) {
        $message = '<div class="alert alert-success text-center">🎉 Donation recorded successfully!</div>';
    } else {
        $message = '<div class="alert alert-danger text-center">❌ Error: ' . $conn->error . '</div>';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Make a Donation</title>
  <!-- ✅ Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<!-- ✅ Navbar (reuse your homepage style) -->
<nav class="navbar navbar-expand-lg bg-white shadow-sm sticky-top">
  <div class="container">
    <a class="navbar-brand fw-bold text-primary" href="index.php">Donation Management</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
        <li class="nav-item"><a class="nav-link active fw-bold" href="donation_form.php">Donate</a></li>
      </ul>
    </div>
  </div>
</nav>

<!-- ✅ Donation Form Section -->
<div class="container py-5">
  <div class="row justify-content-center">
    <div class="col-md-6">

      <div class="card shadow-lg border-0 rounded-4">
        <div class="card-body p-4">
          <h3 class="text-center text-primary mb-4">💙 Make a Donation</h3>

          <!-- Show Success/Error Message -->
          <?php if (!empty($message)) echo $message; ?>

          <form method="POST" action="donation_form.php">
            <div class="mb-3">
              <label for="nic" class="form-label">Donor NIC Number</label>
              <input type="text" class="form-control" id="nic" name="nic" placeholder="Enter NIC" required>
            </div>

            <div class="mb-3">
              <label for="campaign_id" class="form-label">Campaign ID</label>
              <input type="number" class="form-control" id="campaign_id" name="campaign_id" placeholder="Enter Campaign ID" required>
            </div>

            <div class="mb-3">
              <label for="amount" class="form-label">Donation Amount (LKR)</label>
              <input type="number" step="0.01" class="form-control" id="amount" name="amount" placeholder="Enter Amount" required>
            </div>

            <div class="d-grid">
              <button type="submit" class="btn btn-success btn-lg rounded-pill">Donate Now</button>
            </div>
          </form>
        </div>
      </div>

    </div>
  </div>
</div>

<!-- ✅ Footer -->
<footer class="bg-white text-center py-3 border-top mt-5">
  <p class="mb-0">© <?php echo date("Y"); ?> Donation Management System. All rights reserved.</p>
</footer>

<!-- ✅ Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
