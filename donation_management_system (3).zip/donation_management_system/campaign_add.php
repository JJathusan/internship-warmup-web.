<?php
include 'db_connection.php';
session_start();

// Allow only admin
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title       = $_POST['title'];
    $description = $_POST['description'];
  
    $start_date  = $_POST['start_date'];
    $end_date    = $_POST['end_date'];

    $sql = "INSERT INTO campaigns (title, description,  start_date, end_date) 
            VALUES ('$title', '$description',  '$start_date', '$end_date')";

    if ($conn->query($sql) === TRUE) {
        $message = "<div class='alert alert-success'>✅ Campaign added successfully!</div>";
    } else {
        $message = "<div class='alert alert-danger'>❌ Error: " . $conn->error . "</div>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Add Campaign</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container mt-5">
  <div class="card shadow-lg p-4">
    <h2 class="text-center text-primary">➕ Add New Campaign</h2>
    <hr>
    <?php if ($message) echo $message; ?>
    <form method="POST" action="campaign_add.php">
      <div class="mb-3">
        <label class="form-label">Campaign Title</label>
        <input type="text" name="title" class="form-control" required>
      </div>
      <div class="mb-3">
        <label class="form-label">Description</label>
        <textarea name="description" class="form-control" rows="4" required></textarea>
      </div>
      
      <div class="row">
        <div class="col-md-6 mb-3">
          <label class="form-label">Start Date</label>
          <input type="date" name="start_date" class="form-control" required>
        </div>
        <div class="col-md-6 mb-3">
          <label class="form-label">End Date</label>
          <input type="date" name="end_date" class="form-control" required>
        </div>
      </div>
      <button type="submit" class="btn btn-primary w-100">Save Campaign</button>
    </form>
  </div>
</div>

</body>
</html>
