<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Archers Tek</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="styles.css">
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-light bg-white border-bottom">
    <div class="container">
        <a class="navbar-brand fw-bold" href="index.php">
            <span style="color: var(--brand);">Archers</span> Tek
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false"
                aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link active" href="index.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#about">About Us</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="contact.php">Contact Us</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- Hero Section -->
<section class="hero text-center py-5">
    <div class="container">
        <h1>We build <span>dependable,human</span>- centered software</h1>
        <p>Technology with a human touch-at Archers Tek.</p>
        <a href="#about" class="btn btn-primary mt-3">Learn More</a>
    </div>
</section>

<!-- About Section -->
<section id="about" class="py-5">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6">
                <h2>About Archers Tek</h2>
                <p>We are passionate about delivering innovative solutions for startups and enterprises.
                   Our team specializes in web applications, APIs, cloud-native services, and cross-platform integrations.</p>
            </div>
            <div class="col-lg-6">
                <img src="images.jpg" alt="About Image" class="img-fluid rounded">
            </div>
        </div>
    </div>
</section>

<!-- Icon Section -->
<section class="icon-section text-center">
    <div class="container">
        <div class="row g-4">

            <!-- Mission -->
            <div class="col-md-3">
                <i class="fas fa-sliders-h"></i>
                <h5 class="mt-3">Mission</h5>
                <p>To craft scalable, secure, and delightful products that solve real problems.</p>
            </div>

            <!-- Values -->
            <div class="col-md-3">
                <i class="fas fa-smile"></i>
                <h5 class="mt-3">Values</h5>
                <p>Clarity, craftsmanship, and care—for our code, our clients, and our teammates.</p>
            </div>

            <!-- What We Do -->
            <div class="col-md-3">
                <i class="fas fa-cloud-upload-alt"></i>
                <h5 class="mt-3">What We Do</h5>
                <p>Web apps, APIs, cloud-native services, and data integration across platforms.</p>
            </div>

            <!-- Who We Serve -->
            <div class="col-md-3">
                <i class="fas fa-users"></i>
                <h5 class="mt-3">Who We Serve</h5>
                <p>Startups and enterprises seeking reliable partners for long-term growth.</p>
            </div>

        </div>
    </div>
</section>

<!-- Footer -->
<footer class="text-center py-3 border-top">
    <p class="mb-0">&copy; 2025 Archers Tek. All rights reserved.</p>
</footer>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
